# rEFInd-Minimalist

A rEFInd-Minimalist for [rEFInd](https://rodsbooks.com/refind/).

![Preview](preview.jpg)

### Usage

Clone this repository into a `themes` directory located inside the refind EFI directory
(usually `/boot/EFI/refind`)

Then add `include themes/rEFInd-Minimalist/theme.conf` at the end of the refind.conf.

To hide unwanted options simply press delete while the icon is selected.
To restore hidden icons use the lower right button.
